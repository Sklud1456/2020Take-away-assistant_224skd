package wm_assistant.begin;

import wm_assistant.ui.FrmMain;

public class wm_assistantStarter {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new FrmMain();
	}

}
