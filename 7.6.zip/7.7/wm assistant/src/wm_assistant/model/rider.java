package wm_assistant.model;

import java.util.Date;

public class rider {
	private int rider_no;
	private String rider_name;
	private Date rider_date;
	private String rider_ID;
	public int getRider_no() {
		return rider_no;
	}
	public void setRider_no(int rider_no) {
		this.rider_no = rider_no;
	}
	public String getRider_name() {
		return rider_name;
	}
	public void setRider_name(String rider_name) {
		this.rider_name = rider_name;
	}
	public Date getRider_date() {
		return rider_date;
	}
	public void setRider_date(Date rider_date) {
		this.rider_date = rider_date;
	}
	public String getRider_ID() {
		return rider_ID;
	}
	public void setRider_ID(String rider_ID) {
		this.rider_ID = rider_ID;
	}
	
	
}
