package wm_assistant.model;

public class manjian {
	private int manjian_no;
	private int merchat_no;
	private double manjian_money;
	private double manjian_youhui;
	private String manjian_withquan;
	public int getManjian_no() {
		return manjian_no;
	}
	public void setManjian_no(int manjian_no) {
		this.manjian_no = manjian_no;
	}
	public int getMerchat_no() {
		return merchat_no;
	}
	public void setMerchat_no(int merchat_no) {
		this.merchat_no = merchat_no;
	}
	public double getManjian_money() {
		return manjian_money;
	}
	public void setManjian_money(double manjian_money) {
		this.manjian_money = manjian_money;
	}
	public double getManjian_youhui() {
		return manjian_youhui;
	}
	public void setManjian_youhui(double manjian_youhui) {
		this.manjian_youhui = manjian_youhui;
	}
	public String getManjian_withquan() {
		return manjian_withquan;
	}
	public void setManjian_withquan(String manjian_withquan) {
		this.manjian_withquan = manjian_withquan;
	}
	
	

}
