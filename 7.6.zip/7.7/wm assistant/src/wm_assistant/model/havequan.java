package wm_assistant.model;

import java.util.Date;

public class havequan {
	private int merchat_no;
	private int quan_no;
	private int user_no;
	private double havequan_youhui;
	private int havequan_number;
	private Date havequan_enddate;
	public int getMerchat_no() {
		return merchat_no;
	}
	public void setMerchat_no(int merchat_no) {
		this.merchat_no = merchat_no;
	}
	public int getQuan_no() {
		return quan_no;
	}
	public void setQuan_no(int quan_no) {
		this.quan_no = quan_no;
	}
	public int getUser_no() {
		return user_no;
	}
	public void setUser_no(int user_no) {
		this.user_no = user_no;
	}
	public double getHavequan_youhui() {
		return havequan_youhui;
	}
	public void setHavequan_youhui(double havequan_youhui) {
		this.havequan_youhui = havequan_youhui;
	}
	public int getHavequan_number() {
		return havequan_number;
	}
	public void setHavequan_number(int havequan_number) {
		this.havequan_number = havequan_number;
	}
	public Date getHavequan_enddate() {
		return havequan_enddate;
	}
	public void setHavequan_enddate(Date havequan_enddate) {
		this.havequan_enddate = havequan_enddate;
	}
	

}
