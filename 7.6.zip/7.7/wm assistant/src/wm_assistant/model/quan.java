package wm_assistant.model;

import java.util.Date;

public class quan {
	private int quan_no;
	private int merchat_no;
	private double quan_youhui;
	private int jidan_jidan;
	private Date quan_startdate;
	public int getQuan_no() {
		return quan_no;
	}
	public void setQuan_no(int quan_no) {
		this.quan_no = quan_no;
	}
	public int getMerchat_no() {
		return merchat_no;
	}
	public void setMerchat_no(int merchat_no) {
		this.merchat_no = merchat_no;
	}
	public double getQuan_youhui() {
		return quan_youhui;
	}
	public void setQuan_youhui(double quan_youhui) {
		this.quan_youhui = quan_youhui;
	}
	public int getJidan_jidan() {
		return jidan_jidan;
	}
	public void setJidan_jidan(int jidan_jidan) {
		this.jidan_jidan = jidan_jidan;
	}
	public Date getQuan_startdate() {
		return quan_startdate;
	}
	public void setQuan_startdate(Date quan_startdate) {
		this.quan_startdate = quan_startdate;
	}
	public Date getQuan_enddate() {
		return quan_enddate;
	}
	public void setQuan_enddate(Date quan_enddate) {
		this.quan_enddate = quan_enddate;
	}
	private Date quan_enddate;

}
