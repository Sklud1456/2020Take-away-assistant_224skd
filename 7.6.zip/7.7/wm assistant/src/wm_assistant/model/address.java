package wm_assistant.model;

public class address {
	private int address_no;
	private int user_no;
	private String address_pri;
	private String address_city;
	private String address_qu;
	private String address_add;
	private String address_man;
	private String address_phone;
	public int getAddress_no() {
		return address_no;
	}
	public void setAddress_no(int address_no) {
		this.address_no = address_no;
	}
	public int getUser_no() {
		return user_no;
	}
	public void setUser_no(int user_no) {
		this.user_no = user_no;
	}
	public String getAddress_pri() {
		return address_pri;
	}
	public void setAddress_pri(String address_pri) {
		this.address_pri = address_pri;
	}
	public String getAddress_city() {
		return address_city;
	}
	public void setAddress_city(String address_city) {
		this.address_city = address_city;
	}
	public String getAddress_qu() {
		return address_qu;
	}
	public void setAddress_qu(String address_qu) {
		this.address_qu = address_qu;
	}
	public String getAddress_add() {
		return address_add;
	}
	public void setAddress_add(String address_add) {
		this.address_add = address_add;
	}
	public String getAddress_man() {
		return address_man;
	}
	public void setAddress_man(String address_man) {
		this.address_man = address_man;
	}
	public String getAddress_phone() {
		return address_phone;
	}
	public void setAddress_phone(String address_phone) {
		this.address_phone = address_phone;
	}

}
