package wm_assistant.model;

public class jidan {
	private int user_no;
	private int quan_no;
	private int merchat_no;
	private int jidan_jidanshu;
	private int jidan_yiyou;
	public int getUser_no() {
		return user_no;
	}
	public void setUser_no(int user_no) {
		this.user_no = user_no;
	}
	public int getQuan_no() {
		return quan_no;
	}
	public void setQuan_no(int quan_no) {
		this.quan_no = quan_no;
	}
	public int getMerchat_no() {
		return merchat_no;
	}
	public void setMerchat_no(int merchat_no) {
		this.merchat_no = merchat_no;
	}
	public int getJidan_jidanshu() {
		return jidan_jidanshu;
	}
	public void setJidan_jidanshu(int jidan_jidanshu) {
		this.jidan_jidanshu = jidan_jidanshu;
	}
	public int getJidan_yiyou() {
		return jidan_yiyou;
	}
	public void setJidan_yiyou(int jidan_yiyou) {
		this.jidan_yiyou = jidan_yiyou;
	}
	
	

}
