package wm_assistant.model;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;

public class users {
	private int user_no;
	private String user_name;
	private String user_sex;
	private String user_password;
	private String user_phone;
	private String user_mail;
	private String user_city;
	private Timestamp user_createtime;
	private String user_vip;
	private Date user_ipvenddate;
	public int getUser_no() {
		return user_no;
	}
	public void setUser_no(int user_no) {
		this.user_no = user_no;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getUser_sex() {
		return user_sex;
	}
	public void setUser_sex(String user_sex) {
		this.user_sex = user_sex;
	}
	public String getUser_password() {
		return user_password;
	}
	public void setUser_password(String user_password) {
		this.user_password = user_password;
	}
	public String getUser_phone() {
		return user_phone;
	}
	public void setUser_phone(String user_phone) {
		this.user_phone = user_phone;
	}
	public String getUser_mail() {
		return user_mail;
	}
	public void setUser_mail(String user_mail) {
		this.user_mail = user_mail;
	}
	public String getUser_city() {
		return user_city;
	}
	public void setUser_city(String user_city) {
		this.user_city = user_city;
	}
	public Timestamp getUser_createtime() {
		return user_createtime;
	}
	public void setUser_createtime(Timestamp user_createtime) {
		this.user_createtime = user_createtime;
	}
	public String getUser_vip() {
		return user_vip;
	}
	public void setUser_vip(String user_vip) {
		this.user_vip = user_vip;
	}
	public Date getUser_ipvenddate() {
		return user_ipvenddate;
	}
	public void setUser_ipvenddate(Date user_ipvenddate) {
		this.user_ipvenddate = user_ipvenddate;
	}
	
	public static final String[] tableTitles={"���","����","�Ա�","����","�ֻ�","����","����","����ʱ��","�Ƿ�ΪVIP","VIP��ֹʱ��"};
	/**
	 * �����и���javabean������޸ı��������룬col��ʾ��������е�����ţ�0��ʼ
	 */
	public String getCell(int col){
		SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		if(col==0) return String.valueOf(user_no);
		else if(col==1) return user_name;
		else if(col==2) return user_sex;
		else if(col==3) return user_password;
		else if(col==4) return user_phone;
		else if(col==5) return user_mail;
		else if(col==6) return user_city;
		else if(col==7) return sdf1.format(user_createtime);
		else if(col==8) return user_vip;
		else if(col==9) return sdf.format(user_ipvenddate);
		
		else return "";
	}
	
	public static final String[] tableTitlesforuser={"����","�Ա�","����","�ֻ�","����","����","����ʱ��","�Ƿ�ΪVIP","VIP��ֹʱ��"};
	/**
	 * �����и���javabean������޸ı��������룬col��ʾ��������е�����ţ�0��ʼ
	 */
	public String getCelluser(int col){
		SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		if(col==0) return user_name;
		else if(col==1) return user_sex;
		else if(col==2) return user_password;
		else if(col==3) return user_phone;
		else if(col==4) return user_mail;
		else if(col==5) return user_city;
		else if(col==6) return sdf1.format(user_createtime);
		else if(col==7) return user_vip;
		else if(col==8) return sdf.format(user_ipvenddate);
		else return "";
	}
	
	

}
