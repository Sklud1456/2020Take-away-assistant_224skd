package wm_assistant.model;

import java.text.SimpleDateFormat;

public class address {
	private int address_no;
	private int user_no;
	private String address_pri;
	private String address_city;
	private String address_qu;
	private String address_add;
	private String address_man;
	private String address_phone;
	public int getAddress_no() {
		return address_no;
	}
	public void setAddress_no(int address_no) {
		this.address_no = address_no;
	}
	public int getUser_no() {
		return user_no;
	}
	public void setUser_no(int user_no) {
		this.user_no = user_no;
	}
	public String getAddress_pri() {
		return address_pri;
	}
	public void setAddress_pri(String address_pri) {
		this.address_pri = address_pri;
	}
	public String getAddress_city() {
		return address_city;
	}
	public void setAddress_city(String address_city) {
		this.address_city = address_city;
	}
	public String getAddress_qu() {
		return address_qu;
	}
	public void setAddress_qu(String address_qu) {
		this.address_qu = address_qu;
	}
	public String getAddress_add() {
		return address_add;
	}
	public void setAddress_add(String address_add) {
		this.address_add = address_add;
	}
	public String getAddress_man() {
		return address_man;
	}
	public void setAddress_man(String address_man) {
		this.address_man = address_man;
	}
	public String getAddress_phone() {
		return address_phone;
	}
	public void setAddress_phone(String address_phone) {
		this.address_phone = address_phone;
	}
	
	public static final String[] tableTitles={"���","�û����","ʡ","��","��","��ϸ��ַ","��ϵ��","�绰"};
	/**
	 * �����и���javabean������޸ı��������룬col��ʾ��������е�����ţ�0��ʼ
	 */
	public String getCell(int col){
		SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		if(col==0) return String.valueOf(address_no);
		else if(col==1) return String.valueOf(user_no);
		else if(col==2) return address_pri;
		else if(col==3) return address_city;
		else if(col==4) return address_qu;
		else if(col==5) return address_add;
		else if(col==6) return address_man;
		else if(col==7) return address_phone;
		
		else return "";
	}
	
	public static final String[] tableTitlesforuser={"�û����","ʡ","��","��","��ϸ��ַ","��ϵ��","�绰"};
	/**
	 * �����и���javabean������޸ı��������룬col��ʾ��������е�����ţ�0��ʼ
	 */
	public String getCelluser(int col){
		SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		if(col==0) return String.valueOf(user_no);
		else if(col==1) return address_pri;
		else if(col==2) return address_city;
		else if(col==3) return address_qu;
		else if(col==4) return address_add;
		else if(col==5) return address_man;
		else if(col==6) return address_phone;
		else return "";
	}
	
	

}
