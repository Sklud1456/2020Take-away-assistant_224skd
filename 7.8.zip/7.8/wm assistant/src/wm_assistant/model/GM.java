package wm_assistant.model;

public class GM {
	private int gm_no;
	private String gm_name;
	private String gm_password;
	public int getGm_no() {
		return gm_no;
	}
	public void setGm_no(int gm_no) {
		this.gm_no = gm_no;
	}
	public String getGm_name() {
		return gm_name;
	}
	public void setGm_name(String gm_name) {
		this.gm_name = gm_name;
	}
	public String getGm_password() {
		return gm_password;
	}
	public void setGm_password(String gm_password) {
		this.gm_password = gm_password;
	}

}
