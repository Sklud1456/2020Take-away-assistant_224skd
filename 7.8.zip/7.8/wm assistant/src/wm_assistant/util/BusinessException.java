package wm_assistant.util;

public class BusinessException extends BaseException {
	public BusinessException(String msg){
		super(msg);
	}
}
