package wm_assistant.contorl;

import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import wm_assistant.model.manjian;
import wm_assistant.model.merchat;
import wm_assistant.model.quan;
import wm_assistant.util.BaseException;
import wm_assistant.util.BusinessException;
import wm_assistant.util.DBUtil;
import wm_assistant.util.DbException;

public class manjianManager {
public static manjian curmanjian=null;
	
	public void addmanjian(merchat m,String name,double money,double youhui,String withquan) throws BaseException {
		if("".equals(name)||name==null) throw new BusinessException("��Ʒ������Ϊ��");
		if("".equals(withquan)||withquan==null) throw new BusinessException("��ѡ���Ƿ���ȯ����");
		if(youhui<0||money<0) throw new BusinessException("����Ϊ����");
		if(!("Y".equals(withquan))&&!("N".equals(withquan)))  throw new BusinessException("��ȯ���Ӳ���������Y��N");
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select * from manjian where merchat_no=? and manjian_name=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1,m.getMerchat_no());
			pst.setString(2,name);
			java.sql.ResultSet rs=pst.executeQuery();
			if(rs.next()) {
				rs.close();
				pst.close();
				throw new BusinessException("�������Ѵ���");
			}
			
			sql="insert into manjian(merchat_no,manjian_name,manjian_money,manjian_youhui,manjian_withquan) values(?,?,?,?,?)";
			pst=conn.prepareStatement(sql);
			pst.setInt(1,m.getMerchat_no());
			pst.setString(2, name);
			pst.setDouble(3, money);
			pst.setDouble(4, youhui);
			pst.setString(5, withquan);
			pst.executeUpdate();
			pst.close();
			
		} catch (SQLException e) {
				e.printStackTrace();
				throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}		
	}
	
	public List<manjian> loadmanjian(merchat m) throws BaseException {
		List<manjian> result=new ArrayList<manjian>();
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select * from manjian where merchat_no=? order by manjian_no asc";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1, m.getMerchat_no());
			java.sql.ResultSet rs=pst.executeQuery();
			while(rs.next()) {
				manjian mj=new manjian();
				mj.setManjian_no(rs.getInt(1));
				mj.setMerchat_no(rs.getInt(2));
				mj.setManjian_name(rs.getString(3));
				mj.setManjian_money(rs.getDouble(4));
				mj.setManjian_youhui(rs.getDouble(5));
				mj.setManjian_withquan(rs.getString(6));
				result.add(mj);
			}
			return result;
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
		}
	}
	
	public void changeMJname(manjian mj,String name)throws BaseException{
		if("".equals(name)||name==null) throw new BusinessException("����������Ϊ��");
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select * from manjian where manjian_no=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1, mj.getManjian_no());
			java.sql.ResultSet rs=pst.executeQuery();
			if(!rs.next()) throw new BusinessException("������������");
			else {
				rs.close();
				pst.close();
				sql="update manjian set manjian_name=? where manjian_no=?";
				pst=conn.prepareStatement(sql);
				pst.setString(1, name);
				pst.setInt(2, mj.getManjian_no());
				pst.executeUpdate();
				pst.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}
	
	public void changeMJmoney(manjian mj,double money)throws BaseException{
		if(money<0) throw new BusinessException("����Ϊ��");
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select * from manjian where manjian_no=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1, mj.getManjian_no());
			java.sql.ResultSet rs=pst.executeQuery();
			if(!rs.next()) throw new BusinessException("������������");
			else {
				rs.close();
				pst.close();
				sql="update manjian set manjian_money=? where manjian_no=?";
				pst=conn.prepareStatement(sql);
				pst.setDouble(1, money);
				pst.setInt(2, mj.getManjian_no());
				pst.executeUpdate();
				pst.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}
	
	public void changeMJyouhui(manjian mj,double youhui)throws BaseException{
		if(youhui<0) throw new BusinessException("�Żݽ���Ϊ��");
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select * from manjian where manjian_no=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1, mj.getManjian_no());
			java.sql.ResultSet rs=pst.executeQuery();
			if(!rs.next()) throw new BusinessException("������������");
			else {
				rs.close();
				pst.close();
				sql="update manjian set manjian_youhui=? where manjian_no=?";
				pst=conn.prepareStatement(sql);
				pst.setDouble(1, youhui);
				pst.setInt(2, mj.getManjian_no());
				pst.executeUpdate();
				pst.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}
	
	
	
	public void changeMJwithquan(manjian mj,String wq)throws BaseException{
		if("".equals(wq)) throw new BusinessException("��ȯ���Ӳ���Ϊ��");
		if(!("Y".equals(wq))&&!("N".equals(wq)))  throw new BusinessException("��ȯ���Ӳ���������Y��N");
		
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select * from manjian where manjian_no=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1, mj.getManjian_no());
			java.sql.ResultSet rs=pst.executeQuery();
			if(!rs.next()) throw new BusinessException("������������");
			
			else {
				rs.close();
				pst.close();
				sql="update manjian set manjian_withquan=? where manjian_no=?";
				pst=conn.prepareStatement(sql);
				pst.setString(1,wq);
				pst.setInt(2,mj.getManjian_no());
				pst.executeUpdate();
				pst.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}
	
	public void deletemanjian(manjian mj) throws BaseException {
		Connection conn=null;
		try {
	
			conn=DBUtil.getConnection();
			String sql="select * from manjian where manjian_no=? ";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1,mj.getManjian_no());
			java.sql.ResultSet rs=pst.executeQuery();
			if(!rs.next()) {
				throw new BusinessException("���Ż�ȯ������");
			}
			rs.close();
			sql="delete from manjian where manjian_no=?";
			pst=conn.prepareStatement(sql);
			pst.setInt(1,mj.getManjian_no());
			pst.executeUpdate();
			pst.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
	}

	
	public static void main(String[] args) {
		manjianManager a=new manjianManager();
		List<manjian> b=new ArrayList<manjian>();
		merchat m =new merchat();
		m.setMerchat_no(4);
		try {
			a.addmanjian(m, "one", 75.0, 10.0, "Y");
			a.addmanjian(m, "two", 50.0, 5.0, "N");
			a.addmanjian(m, "three", 60.0, 10.0, "N");
			a.addmanjian(m, "four", 30.0, 5.0, "N");
			b=a.loadmanjian(m);
			for(int i=0;i<b.size();i++) {
				System.out.println(b.get(i).getManjian_name()+" "+b.get(i).getManjian_money()+" "+b.get(i).getManjian_withquan());	
			}
			a.deletemanjian(b.get(1));
			b=a.loadmanjian(m);
			for(int i=0;i<b.size();i++) {
				System.out.println(b.get(i).getManjian_name()+" "+b.get(i).getManjian_money()+" "+b.get(i).getManjian_withquan());	
			}
			
		} catch (BaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
