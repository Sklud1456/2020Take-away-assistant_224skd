package wm_assistant.contorl;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import wm_assistant.model.address;
import wm_assistant.model.merchat;
import wm_assistant.model.product;
import wm_assistant.model.productsort;
import wm_assistant.model.users;
import wm_assistant.util.BaseException;
import wm_assistant.util.BusinessException;
import wm_assistant.util.DBUtil;
import wm_assistant.util.DbException;

public class addressManager {
	public void addaddress(users us, String pri,String city,String qu,String add,String man,String phone) throws BaseException {
		if("".equals(pri)||pri==null||"".equals(qu)||qu==null||"".equals(city)||city==null||"".equals(add)||add==null
			||"".equals(man)||man==null||phone==null||"".equals(phone)	) throw new BusinessException("������Ϣ����Ϊ��");
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select * from address where user_no=? and address_phone=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1,us.getUser_no());
			pst.setString(2,phone);
			java.sql.ResultSet rs=pst.executeQuery();
			if(rs.next()) {
				rs.close();
				pst.close();
				throw new BusinessException("����Ϣ�Ѵ���");
			}
			sql="insert into address(user_no,address_pri,address_city,address_qu,address_add,address_man,"
				+ "address_phone) values(?,?,?,?,?,?,?)";
			pst=conn.prepareStatement(sql);
			pst.setInt(1,us.getUser_no());
			pst.setString(2,pri);
			pst.setString(3, city);
			pst.setString(4, qu);
			pst.setString(5, add);
			pst.setString(6, man);
			pst.setString(7, phone);
			pst.executeUpdate();
			pst.close();
		} catch (SQLException e) {
				e.printStackTrace();
				throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}		
	}
	
	public static List<address> loadaddress(users us) throws BaseException {
		List<address> result=new ArrayList<address>();
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select * from address where user_no=? order by address_no asc";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1, us.getUser_no());
			java.sql.ResultSet rs=pst.executeQuery();
			while(rs.next()) {
				address add=new address();
				add.setAddress_no(rs.getInt(1));
				add.setUser_no(rs.getInt(2));
				add.setAddress_pri(rs.getString(3));
				add.setAddress_city(rs.getString(4));
				add.setAddress_qu(rs.getString(5));
				add.setAddress_add(rs.getString(6));
				add.setAddress_man(rs.getString(7));
				add.setAddress_phone(rs.getString(8));				
				result.add(add);
			}
			return result;
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}
	
	public void changeaddressPri(address Add, String pri) throws BaseException {
		if("".equals(pri)||pri==null) throw new BusinessException("ʡ����Ϣ����Ϊ��");
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select * from address where address_no=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1,Add.getAddress_no());
			java.sql.ResultSet rs=pst.executeQuery();
			if(rs.next()) {
				rs.close();
				pst.close();
				throw new BusinessException("�õ�ַ�Ѵ���");
			}
			sql="update address set address_pri=? where address_no=?";
			pst=conn.prepareStatement(sql);
			pst.setString(1,pri);
			pst.setInt(2, Add.getAddress_no());
			pst.executeUpdate();
			pst.close();
		} catch (SQLException e) {
				e.printStackTrace();
				throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}		
	}
	
	public void changeaddressCity(address Add, String city) throws BaseException {
		if("".equals(city)||city==null) throw new BusinessException("������Ϣ����Ϊ��");
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select * from address where address_no=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1,Add.getAddress_no());
			java.sql.ResultSet rs=pst.executeQuery();
			if(rs.next()) {
				rs.close();
				pst.close();
				throw new BusinessException("�õ�ַ�Ѵ���");
			}
			sql="update address set address_city=? where address_no=?";
			pst=conn.prepareStatement(sql);
			pst.setString(1,city);
			pst.setInt(2, Add.getAddress_no());
			pst.executeUpdate();
			pst.close();
		} catch (SQLException e) {
				e.printStackTrace();
				throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}		
	}
	
	public void changeaddressQu(address Add, String qu) throws BaseException {
		if("".equals(qu)||qu==null) throw new BusinessException("������Ϣ����Ϊ��");
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select * from address where address_no=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1,Add.getAddress_no());
			java.sql.ResultSet rs=pst.executeQuery();
			if(rs.next()) {
				rs.close();
				pst.close();
				throw new BusinessException("�õ�ַ�Ѵ���");
			}
			sql="update address set address_qu=? where address_no=?";
			pst=conn.prepareStatement(sql);
			pst.setString(1,qu);
			pst.setInt(2, Add.getAddress_no());
			pst.executeUpdate();
			pst.close();
		} catch (SQLException e) {
				e.printStackTrace();
				throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}		
	}
	
	public void changeaddressAdd(address Add, String add) throws BaseException {
		if("".equals(add)||add==null) throw new BusinessException("��ַ��ϸ��Ϣ����Ϊ��");
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select * from address where address_no=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1,Add.getAddress_no());
			java.sql.ResultSet rs=pst.executeQuery();
			if(rs.next()) {
				rs.close();
				pst.close();
				throw new BusinessException("�õ�ַ�Ѵ���");
			}
			sql="update address set address_add=? where address_no=?";
			pst=conn.prepareStatement(sql);
			pst.setString(1,add);
			pst.setInt(2, Add.getAddress_no());
			pst.executeUpdate();
			pst.close();
		} catch (SQLException e) {
				e.printStackTrace();
				throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}		
	}
	
	public void changeaddressMan(address Add, String man) throws BaseException {
		if("".equals(man)||man==null) throw new BusinessException("��ϵ����Ϣ����Ϊ��");
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select * from address where address_no=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1,Add.getAddress_no());
			java.sql.ResultSet rs=pst.executeQuery();
			if(rs.next()) {
				rs.close();
				pst.close();
				throw new BusinessException("�õ�ַ�Ѵ���");
			}
			sql="update address set address_man=? where address_no=?";
			pst=conn.prepareStatement(sql);
			pst.setString(1,man);
			pst.setInt(2, Add.getAddress_no());
			pst.executeUpdate();
			pst.close();
		} catch (SQLException e) {
				e.printStackTrace();
				throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}		
	}
	
	public void changeaddressPhone(address Add, String phone) throws BaseException {
		if("".equals(phone)||phone==null) throw new BusinessException("�绰��Ϣ����Ϊ��");
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select * from address where address_no=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1,Add.getAddress_no());
			java.sql.ResultSet rs=pst.executeQuery();
			if(rs.next()) {
				rs.close();
				pst.close();
				throw new BusinessException("�õ�ַ�Ѵ���");
			}
			sql="update address set address_phone=? where address_no=?";
			pst=conn.prepareStatement(sql);
			pst.setString(1,phone);
			pst.setInt(2, Add.getAddress_no());
			pst.executeUpdate();
			pst.close();
		} catch (SQLException e) {
				e.printStackTrace();
				throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}		
	}
	
	public void updateaddress(address Add, String pri,String city,String qu,String add,String man,String phone) throws BaseException {
		if("".equals(pri)||pri==null||"".equals(qu)||qu==null||"".equals(city)||city==null||"".equals(add)||add==null
			||"".equals(man)||man==null||phone==null||"".equals(phone)	) throw new BusinessException("������Ϣ����Ϊ��");
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select * from address where address_no=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1,Add.getAddress_no());
			java.sql.ResultSet rs=pst.executeQuery();
			if(rs.next()) {
				rs.close();
				pst.close();
				throw new BusinessException("����Ϣ�Ѵ���");
			}
			sql="update address set address_pri=?,set address_city=?,set address_qu=?,set address_add=?,"
					+ "set address_man=?,set address_phone=? where address_no=?";
			pst=conn.prepareStatement(sql);
			pst.setString(1,pri);
			pst.setString(2, city);
			pst.setString(3, qu);
			pst.setString(4, add);
			pst.setString(5, man);
			pst.setString(6, phone);
			pst.setInt(7, Add.getAddress_no());
			pst.executeUpdate();
			pst.close();
		} catch (SQLException e) {
				e.printStackTrace();
				throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}		
	}
	
	public void deleteaddress(address add) throws BaseException {
		Connection conn=null;
		try {
	
			conn=DBUtil.getConnection();
			String sql="select * from address where address_no=? ";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1,add.getAddress_no());
			java.sql.ResultSet rs=pst.executeQuery();
			if(!rs.next()) {
				throw new BusinessException("�õ�ַ������");
			}
			rs.close();
			sql="delete from address where address_no=?";
			pst=conn.prepareStatement(sql);
			pst.setInt(1,add.getAddress_no());
			pst.executeUpdate();
			pst.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}
	
	public static void main(String[] args) {
		addressManager a=new addressManager();
		List<address> b=new ArrayList<address>();
		try {
			users us=new users();
			us.setUser_no(1);
			a.addaddress(us, "�㽭", "����", "����", "�㽭ʡ�����й��������ݽ�", "skd", "1568715467");
			a.addaddress(us,"�㽭","����","����","˳�������ȥ","qwe","7861189445");
			a.addaddress(us,"�㽭","����","����","˳�������ȥ","qwqwe","74567889445");
			b=a.loadaddress(us);
			for(int i=0;i<b.size();i++) {
				System.out.println(b.get(i).getAddress_no()+" "+b.get(i).getAddress_add()+" "+b.get(i).getAddress_man());
			}
			a.deleteaddress(b.get(1));
			b=a.loadaddress(us);
			for(int i=0;i<b.size();i++) {
				System.out.println(b.get(i).getAddress_no()+" "+b.get(i).getAddress_add()+" "+b.get(i).getAddress_man());
			}
			
		} catch (BaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	

}
