package wm_assistant.contorl;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import wm_assistant.begin.wm_assistantUtil;
import wm_assistant.model.GM;
import wm_assistant.model.merchat;
import wm_assistant.model.users;
import wm_assistant.util.BaseException;
import wm_assistant.util.BusinessException;
import wm_assistant.util.DBUtil;
import wm_assistant.util.DbException;

public class userManager {
	public static users currentuser=null;
	public users login(String user_name, String user_password) throws BaseException {
		
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select * from users where user_name=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1,user_name);
			java.sql.ResultSet rs=pst.executeQuery();
			if(!rs.next()) throw new BusinessException("�û�������");
			users user=new users();
			user.setUser_no(rs.getInt(1));
			user.setUser_name(rs.getString(2));
			user.setUser_sex(rs.getString(3));
			user.setUser_password(rs.getString(4));
			user.setUser_phone(rs.getString(5));
			user.setUser_mail(rs.getString(6));
			user.setUser_city(rs.getString(7));
			user.setUser_vip(rs.getString(9));
			user.setUser_ipvenddate(rs.getDate(10));
			System.out.println(user.getUser_name());
			rs.close();
			pst.close();
			return user;
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}
	
	public static List<users> loadUser() throws BaseException {
		List<users> result=new ArrayList<users>();
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select * from users";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			java.sql.ResultSet rs=pst.executeQuery();
			while(rs.next()) {
				users us=new users();
				us.setUser_no(rs.getInt(1));
				us.setUser_name(rs.getString(2));
				us.setUser_sex(rs.getString(3));
				us.setUser_password(rs.getString(4));
				us.setUser_phone(rs.getString(5));
				us.setUser_mail(rs.getString(6));
				us.setUser_city(rs.getString(7));
				us.setUser_createtime(rs.getTimestamp(8));
				us.setUser_vip(rs.getString(9));
				us.setUser_ipvenddate(rs.getDate(10));
				result.add(us);
			}
			return result;
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
		}
	}
	
	public void createUser(users user)throws BaseException{
		if(user.getUser_name()==null || "".equals(user.getUser_name()) || user.getUser_name().length()>20){
			throw new BusinessException("�û�id���ɲ������Ҳ��ܳ���20����");
		}
		if(user.getUser_password()==null || "".equals(user.getUser_password())){
			throw new BusinessException("�������û�����");
		}
		
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select gm_name,user_name from gm,users where gm_name=? || user_name=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1,user.getUser_name());
			pst.setString(2,user.getUser_name());
			java.sql.ResultSet rs=pst.executeQuery();
			if(rs.next()) throw new BusinessException("�û����Ѵ���");
			rs.close();
			pst.close();
			sql="insert into users(user_name,user_sex,user_password,user_phone,user_mail,user_city,user_vip,user_vipenddate) values(?,?,?,?,?,?,'N','1900-01-01')";
			pst=conn.prepareStatement(sql);
			pst.setString(1, user.getUser_name());
			pst.setString(2, user.getUser_sex());
			pst.setString(3, user.getUser_password());
			pst.setString(4, user.getUser_phone());
			pst.setString(5, user.getUser_mail());
			pst.setString(6, user.getUser_city());
			pst.execute();
			pst.close();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}
	
	public void changeuserName(users us,String name)throws BaseException{
		if(name==null || "".equals(name) || name.length()>20) throw new BusinessException("���ֳ���Ϊ1-20");
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select user_name from users where user_no=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1,us.getUser_no());
			java.sql.ResultSet rs=pst.executeQuery();
			if(!rs.next()) throw new BusinessException("�û�������");
			rs.close();
			pst.close();
			sql="update users set user_name=? where user_no=?";
			pst=conn.prepareStatement(sql);
			pst.setString(1, name);
			pst.setInt(2, us.getUser_no());
			pst.execute();
			pst.close();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}
	
	public void changeuserPwd(users us,String oldPwd,String newPwd)throws BaseException{
		if(oldPwd==null) throw new BusinessException("ԭ����Ϊ��");
		if(newPwd==null || "".equals(newPwd) || newPwd.length()>20) throw new BusinessException("�����볤��Ϊ1-20");
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select * from users where user_no=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1,us.getUser_no());
			
			java.sql.ResultSet rs=pst.executeQuery();
			if(!rs.next()) throw new BusinessException("�û�������");
			if(oldPwd.equals(rs.getString(4))) {
				rs.close();
				pst.close();
				sql="update users set user_password=? where user_no=?";
				pst=conn.prepareStatement(sql);
				pst.setString(1, newPwd);
				pst.setInt(2, us.getUser_no());
				pst.execute();
				pst.close();
			}
			else {
				rs.close();
				pst.close();
				throw new BusinessException("�����벻һ��");
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}
	
	public void changeuserSex(users us,String sex)throws BaseException{
		if(sex==null || "".equals(sex) ||!("��".equals(sex))||!("Ů".equals(sex))) throw new BusinessException("�Ա���������");
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select * from users where user_no=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1,us.getUser_no());
			java.sql.ResultSet rs=pst.executeQuery();
			if(!rs.next()) throw new BusinessException("�û�������");
			rs.close();
			pst.close();
			sql="update users set user_sex=? where user_no=?";
			pst=conn.prepareStatement(sql);
			pst.setString(1, sex);
			pst.setInt(2, us.getUser_no());
			pst.execute();
			pst.close();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}
	
	public void changeuserPhone(users us,String phone)throws BaseException{
		if( "".equals(phone) ||wm_assistantUtil.isNumericZidai(phone)==false) throw new BusinessException("�绰��������");
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select * from users where user_no=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1,us.getUser_no());
			java.sql.ResultSet rs=pst.executeQuery();
			if(!rs.next()) throw new BusinessException("�û�������");
			rs.close();
			pst.close();
			sql="update users set user_phone=? where user_no=?";
			pst=conn.prepareStatement(sql);
			pst.setString(1, phone);
			pst.setInt(2, us.getUser_no());
			pst.execute();
			pst.close();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}
	
	public void changeuserMail(users us,String mail)throws BaseException{
		if(mail==null || "".equals(mail) ) throw new BusinessException("������������");
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select * from users where user_no=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1,us.getUser_no());
			java.sql.ResultSet rs=pst.executeQuery();
			if(!rs.next()) throw new BusinessException("�û�������");
			rs.close();
			pst.close();
			sql="update users set user_mail=? where user_no=?";
			pst=conn.prepareStatement(sql);
			pst.setString(1, mail);
			pst.setInt(2, us.getUser_no());
			pst.execute();
			pst.close();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}
	
	public void changeuserCity(users us,String city)throws BaseException{
		if(city==null || "".equals(city) ) throw new BusinessException("������������");
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select * from users where user_no=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1,us.getUser_no());
			java.sql.ResultSet rs=pst.executeQuery();
			if(!rs.next()) throw new BusinessException("�û�������");
			rs.close();
			pst.close();
			sql="update users set user_city=? where user_no=?";
			pst=conn.prepareStatement(sql);
			pst.setString(1, city);
			pst.setInt(2, us.getUser_no());
			pst.execute();
			pst.close();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}
	
	public void changeuserVip(users us,String vip)throws BaseException{
		if(vip==null || "".equals(vip) ||(!("Y".equals(vip))&&!("N".equals(vip)))) throw new BusinessException("�Ƿ�vip��������");
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select * from users where user_no=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1,us.getUser_no());
			java.sql.ResultSet rs=pst.executeQuery();
			if(!rs.next()) throw new BusinessException("�û�������");
			rs.close();
			pst.close();
			sql="update users set user_vip=? where user_no=?";
			pst=conn.prepareStatement(sql);
			pst.setString(1, vip);
			pst.setInt(2, us.getUser_no());
			pst.execute();
			pst.close();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}
	
	public void changeuserVipenddate(users us,Date d)throws BaseException{
		if(d==null ) throw new BusinessException("������������");
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select * from users where user_no=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1,us.getUser_no());
			java.sql.ResultSet rs=pst.executeQuery();
			if(!rs.next()) throw new BusinessException("�û�������");
			rs.close();
			pst.close();
			sql="update users set user_vipenddate=? where user_no=?";
			pst=conn.prepareStatement(sql);
			pst.setDate(1,new java.sql.Date(d.getTime()));
			pst.setInt(2, us.getUser_no());
			pst.execute();
			pst.close();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}
	
	public void deleteUser(users us) throws BaseException {
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select * from users where user_no=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1,us.getUser_no());
			java.sql.ResultSet rs=pst.executeQuery();
			
			if(!rs.next()) {
				pst.close();
				rs.close();
				throw new  BusinessException("���û�������");
			}
			else {
				pst.close();
				rs.close();
				sql="delete from users where user_no=?";
				pst=conn.prepareStatement(sql);
				pst.setInt(1,us.getUser_no());
				pst.executeUpdate();
				pst.close();
				rs.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}
	

}
