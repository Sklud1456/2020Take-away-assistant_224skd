package wm_assistant.contorl;

public class havequamManager {

}
