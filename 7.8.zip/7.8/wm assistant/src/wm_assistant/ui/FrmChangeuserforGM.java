package wm_assistant.ui;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Dialog;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import wm_assistant.begin.wm_assistantUtil;
import wm_assistant.contorl.quanManager;
import wm_assistant.contorl.userManager;
import wm_assistant.model.quan;
import wm_assistant.model.users;
import wm_assistant.util.BaseException;
import wm_assistant.util.BusinessException;

public class FrmChangeuserforGM extends JDialog implements ActionListener {
	private JPanel toolBar = new JPanel();
	private JPanel workPane = new JPanel();
	private Button btnOk = new Button("ȷ��");
	private Button btnCancel = new Button("ȡ��");
	private JLabel labelName = new JLabel("���ƣ�");
	private JLabel labelSex = new JLabel("�Ա�");
	private JLabel labelPhone = new JLabel("�绰��");
	private JLabel labelMail = new JLabel("���ʣ�");
	private JLabel labelCity = new JLabel("���У�");
	private JLabel labelVip = new JLabel("�Ƿ�VIP��");
	private JLabel labelVipenddate = new JLabel("VIP��ֹ���ڣ�");
	
	private JTextField edtName = new JTextField(20);
	private JTextField edtSex = new JTextField(20);
	private JTextField edtPhone = new JTextField(20);
	private JTextField edtMail = new JTextField(20);
	private JTextField edtCity = new JTextField(20);
	private JTextField edtVip = new JTextField(20);
	private JTextField edtVipenddate = new JTextField(20);
	
	public FrmChangeuserforGM (Dialog f, String s, boolean b) {
		super(f, s, b);
		toolBar.setLayout(new FlowLayout(FlowLayout.RIGHT));
		toolBar.add(btnOk);
		toolBar.add(btnCancel);
		this.getContentPane().add(toolBar, BorderLayout.SOUTH);
		workPane.add(labelName);
		workPane.add(edtName);
		workPane.add(labelSex);
		workPane.add(edtSex);
		workPane.add(labelPhone);
		workPane.add(edtPhone);
		workPane.add(labelMail);
		workPane.add(edtMail);
		workPane.add(labelCity);
		workPane.add(edtCity);
		workPane.add(labelVip);
		workPane.add(edtVip);
		workPane.add(labelVipenddate);
		workPane.add(edtVipenddate);
		
		this.getContentPane().add(workPane, BorderLayout.CENTER);
		this.setSize(300, 280);
		// ��Ļ������ʾ
		double width = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
		double height = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
		this.setLocation((int) (width - this.getWidth()) / 2,
				(int) (height - this.getHeight()) / 2);

		this.validate();
		this.btnOk.addActionListener(this);
		this.btnCancel.addActionListener(this);
		
	}
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==this.btnCancel) {
			this.setVisible(false);
			return;
		}
		else if(e.getSource()==this.btnOk){
			try {
				if(userManager.currentuser==null) throw new BusinessException("δָ���û�");
				users us=userManager.currentuser;
				
				if(!("".equals(edtName.getText()))) {
					String name=edtName.getText();
					wm_assistantUtil.usermanager.changeuserName(us, name);
				}
				if(!("".equals(edtSex.getText()))) {
					String sex=edtSex.getText();
					if(!("��".equals(sex))||!("Ů".equals(sex))) {
						throw  new BusinessException("�Ա�ֻ������Ů ");
					}
					wm_assistantUtil.usermanager.changeuserSex(us, sex);
				}
				if(!("".equals(edtPhone.getText()))) {
					if(wm_assistantUtil.isNumericZidai(edtPhone.getText())==false) {
						throw  new BusinessException("�绰ֻ�������� ");
					}
					String phone=edtPhone.getText();
					
					wm_assistantUtil.usermanager.changeuserPhone(us, phone);
				}
				
				if(!("".equals(edtMail.getText()))) {
					String mail=edtMail.getText();	
					wm_assistantUtil.usermanager.changeuserMail(us, mail);
				}
				
				if(!("".equals(edtCity.getText()))) {
					String city=edtCity.getText();
					
					wm_assistantUtil.usermanager.changeuserCity(us, city);
				}
				
				if(!("".equals(edtVip.getText()))) {
					String vip=edtVip.getText();
					if(!("Y".equals(vip))&&!("N".equals(vip))) {
						throw  new BusinessException("VIPֻ����Y��N");
					}
					
					wm_assistantUtil.usermanager.changeuserVip(us, vip);
				}
				
				if(!("".equals(edtVipenddate.getText()))) {
					SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
					Date d1=new Date();
					try {
						d1=sdf.parse(edtVipenddate.getText());
					} catch (ParseException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					wm_assistantUtil.usermanager.changeuserVipenddate(us, d1);
				}
				userManager.currentuser=null;
				this.setVisible(false);
			} catch (BaseException e1) {
				JOptionPane.showMessageDialog(null, e1.getMessage(), "����",JOptionPane.ERROR_MESSAGE);
				return;
			}
		}
		
	}
	
}
