package wm_assistant.ui;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Dialog;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import wm_assistant.begin.wm_assistantUtil;
import wm_assistant.contorl.manjianManager;
import wm_assistant.contorl.quanManager;
import wm_assistant.model.manjian;
import wm_assistant.model.quan;
import wm_assistant.util.BaseException;
import wm_assistant.util.BusinessException;

public class FrmChangemanjian extends JDialog implements ActionListener {
	private JPanel toolBar = new JPanel();
	private JPanel workPane = new JPanel();
	private Button btnOk = new Button("ȷ��");
	private Button btnCancel = new Button("ȡ��");
	private JLabel labelName = new JLabel("���ƣ�");
	private JLabel labelMoney = new JLabel("������");
	private JLabel labelYouhui = new JLabel("�Żݽ�");
	private JLabel labelWithquan = new JLabel("�ܷ���ȯ���ӣ�");
	
	private JTextField edtName = new JTextField(20);
	private JTextField edtMoney = new JTextField(20);
	private JTextField edtYouhui= new JTextField(20);
	private JTextField edtWithquan = new JTextField(20);
	
	public FrmChangemanjian (Dialog f, String s, boolean b) {
		super(f, s, b);
		toolBar.setLayout(new FlowLayout(FlowLayout.RIGHT));
		toolBar.add(btnOk);
		toolBar.add(btnCancel);
		this.getContentPane().add(toolBar, BorderLayout.SOUTH);
		workPane.add(labelName);
		workPane.add(edtName);
		workPane.add(labelMoney);
		workPane.add(edtMoney);
		workPane.add(labelYouhui);
		workPane.add(edtYouhui);
		workPane.add(labelWithquan);
		workPane.add(edtWithquan);
		
		this.getContentPane().add(workPane, BorderLayout.CENTER);
		this.setSize(335, 200);
		// ��Ļ������ʾ
		double width = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
		double height = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
		this.setLocation((int) (width - this.getWidth()) / 2,
				(int) (height - this.getHeight()) / 2);

		this.validate();
		this.btnOk.addActionListener(this);
		this.btnCancel.addActionListener(this);
		
	}
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==this.btnCancel) {
			this.setVisible(false);
			return;
		}
		else if(e.getSource()==this.btnOk){
			try {
				if(manjianManager.curmanjian==null) throw new BusinessException("δָ������");
				manjian mj=manjianManager.curmanjian;
				
				if(!("".equals(edtName.getText()))) {
					String name=edtName.getText();
					wm_assistantUtil.manjianmanager.changeMJname(mj, name);
				}
				if(!("".equals(edtMoney.getText()))) {
					if(wm_assistantUtil.isNumericZidai(edtMoney.getText())==false) {
						throw  new BusinessException("�������ֻ�������� ");
					}
					double money=Double.parseDouble(edtMoney.getText());
					wm_assistantUtil.manjianmanager.changeMJmoney(mj, money);
				}
				if(!("".equals(edtYouhui.getText()))) {
					if(wm_assistantUtil.isNumericZidai(edtYouhui.getText())==false) {
						throw  new BusinessException("�Żݽ��ֻ�������� ");
					}
					int youhui=Integer.parseInt(edtYouhui.getText());
					
					wm_assistantUtil.manjianmanager.changeMJyouhui(mj, youhui);
				}
				
				if(!("".equals(edtWithquan.getText()))) {
					String withquan=edtWithquan.getText();
					wm_assistantUtil.manjianmanager.changeMJwithquan(mj, withquan);
				}
				manjianManager.curmanjian=null;
				
				this.setVisible(false);
			} catch (BaseException e1) {
				JOptionPane.showMessageDialog(null, e1.getMessage(), "����",JOptionPane.ERROR_MESSAGE);
				return;
			}
		}
		
	}

}
