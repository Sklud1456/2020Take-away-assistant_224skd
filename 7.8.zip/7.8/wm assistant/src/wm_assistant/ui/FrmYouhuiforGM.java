package wm_assistant.ui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import wm_assistant.begin.wm_assistantUtil;
import wm_assistant.contorl.GMManager;
import wm_assistant.contorl.manjianManager;
import wm_assistant.contorl.merchatManager;
import wm_assistant.contorl.productManager;
import wm_assistant.contorl.productsortManager;
import wm_assistant.contorl.quanManager;
import wm_assistant.model.manjian;
import wm_assistant.model.merchat;
import wm_assistant.model.product;
import wm_assistant.model.productsort;
import wm_assistant.model.quan;
import wm_assistant.util.BaseException;
import wm_assistant.util.BusinessException;

public class FrmYouhuiforGM  extends JDialog implements ActionListener {
	private JMenuBar menubar=new JMenuBar(); ;
	private JMenu menu_merchat=new JMenu("�̼�");
	private JMenu menu_quan=new JMenu("�Ż�ȯ");
	private JMenu menu_manjian=new JMenu("����");
   
    private JMenuItem  menuItem_Addquan=new JMenuItem("�½��Ż�ȯ");
    private JMenuItem  menuItem_Changequan=new JMenuItem("�޸��Ż�ȯ");
    private JMenuItem  menuItem_Deletequan=new JMenuItem("ɾ���Ż�ȯ");
    private JMenuItem  menuItem_Addmanjian=new JMenuItem("�½�����");
    private JMenuItem  menuItem_Changemanjian=new JMenuItem("�޸�����");
    private JMenuItem  menuItem_Deletemanjian=new JMenuItem("ɾ������");
    private JMenuItem  menuItem_Fresh=new JMenuItem("ˢ��");
    
    private JPanel statusBar = new JPanel();
    
    private Object merchatTitle[]=merchat.tableTitles;
	private Object merchatData[][];
   	DefaultTableModel merchatModel=new DefaultTableModel();
   	private JTable dataTablemerchat=new JTable(merchatModel);
   	
   	private Object tblquanTitle[]=quan.tablequanTitles;
   	private Object tblquan[][];
   	DefaultTableModel tabquanModel=new DefaultTableModel();
   	private JTable dataquan=new JTable(tabquanModel);

   	private Object tblmanjianTitle[]=manjian.tablemanjianTitles;
   	private Object tblmanjian[][];
   	DefaultTableModel tabmanjianModel=new DefaultTableModel();
   	private JTable datamanjian=new JTable(tabmanjianModel);
   	
   	private merchat curmerchat=null;
   	private quan curquan=null;
	private manjian curmanjian=null;
	List<merchat> allmerchat=null;
	List<quan> allquan=null;
	List<manjian> allmanjian=null;
   	private void reloadmerchatTable(){//���ǲ������ݣ���Ҫ��ʵ�����滻
		try {
			allmerchat=merchatManager.loadMerchat();
		} catch (BaseException e) {
			JOptionPane.showMessageDialog(null, e.getMessage(), "����",JOptionPane.ERROR_MESSAGE);
			return;
		}
		merchatData =  new Object[allmerchat.size()][merchat.tableTitles.length];
		for(int i=0;i<allmerchat.size();i++){
			for(int j=0;j<merchat.tableTitles.length;j++)
				merchatData[i][j]=allmerchat.get(i).getCell(j);
		}
		merchatModel.setDataVector(merchatData,merchatTitle);
		this.dataTablemerchat.validate();
		this.dataTablemerchat.repaint();
	}
   	private void reloadquanTabel(int merchatIdx){
		if(merchatIdx<0) return;
		curmerchat=allmerchat.get(merchatIdx);
		merchatManager.currentmerchat=curmerchat;
		try {
			allquan =wm_assistantUtil.quanmanager.loadquan(curmerchat);
		} catch (BaseException e) {
			JOptionPane.showMessageDialog(null, e.getMessage(), "����",JOptionPane.ERROR_MESSAGE);
			return;
		}
		tblquan =new Object[allquan.size()][quan.tablequanTitles.length];
		for(int i=0;i<allquan.size();i++){
			for(int j=0;j<quan.tablequanTitles.length;j++)
				tblquan[i][j]=allquan.get(i).getCell(j);
		}
		
		tabquanModel.setDataVector(tblquan,tblquanTitle);
		this.dataquan.validate();
		this.dataquan.repaint();
	}
	private void reloadmanjianTabel(int merchatIdx){
		if(merchatIdx<0) return;
		curmerchat=allmerchat.get(merchatIdx);
		merchatManager.currentmerchat=curmerchat;
		try {
			allmanjian=wm_assistantUtil.manjianmanager.loadmanjian(curmerchat);
		} catch (BaseException e) {
			JOptionPane.showMessageDialog(null, e.getMessage(), "����",JOptionPane.ERROR_MESSAGE);
			return;
		}
		tblmanjian =new Object[allmanjian.size()][manjian.tablemanjianTitles.length];
		for(int i=0;i<allmanjian.size();i++){
			for(int j=0;j<manjian.tablemanjianTitles.length;j++)
				tblmanjian[i][j]=allmanjian.get(i).getCell(j);
		}
		
		tabmanjianModel.setDataVector(tblmanjian,tblmanjianTitle);
		this.datamanjian.validate();
		this.datamanjian.repaint();
	}
	public FrmYouhuiforGM(FrmMerchatforGM frmMerchatforGM, String s, boolean b) {
		this.setSize(1500, 800);
		
		double width = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
		double height = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
		this.setLocation((int) (width - this.getWidth()) / 2,
				(int) (height - this.getHeight()) / 2);
		
		menubar.add(menu_merchat);this.menu_merchat.addActionListener(this);
		menubar.add(menu_quan);this.menu_quan.addActionListener(this);
		menubar.add(menu_manjian);this.menu_manjian.addActionListener(this);
		this.menu_merchat.add(this.menuItem_Fresh); this.menuItem_Fresh.addActionListener(this);
		this.menu_quan.add(this.menuItem_Addquan); this.menuItem_Addquan.addActionListener(this);
		this.menu_quan.add(this.menuItem_Changequan); this.menuItem_Changequan.addActionListener(this);
		this.menu_quan.add(this.menuItem_Deletequan); this.menuItem_Deletequan.addActionListener(this);
		this.menu_manjian.add(this.menuItem_Addmanjian); this.menuItem_Addmanjian.addActionListener(this);
		this.menu_manjian.add(this.menuItem_Changemanjian); this.menuItem_Changemanjian.addActionListener(this);
		this.menu_manjian.add(this.menuItem_Deletemanjian); this.menuItem_Deletemanjian.addActionListener(this);
		
		this.setJMenuBar(menubar);
		
		this.getContentPane().add(new JScrollPane(this.dataTablemerchat), BorderLayout.WEST);
		this.reloadmerchatTable();
		
		this.dataTablemerchat.addMouseListener(new MouseAdapter (){
			public void mouseClicked(MouseEvent e) {
				int i=FrmYouhuiforGM.this.dataTablemerchat.getSelectedRow();
				if(i<0) {
					return;
				}
				FrmYouhuiforGM.this.reloadquanTabel(i);
				FrmYouhuiforGM.this.reloadmanjianTabel(i);
			}
	    	
	    });
		this.getContentPane().add(new JScrollPane(this.dataquan), BorderLayout.CENTER);
	
		
	    this.getContentPane().add(new JScrollPane(this.datamanjian), BorderLayout.EAST);
	    
	    statusBar.setLayout(new FlowLayout(FlowLayout.LEFT));
	    JLabel label=new JLabel("����!"+GMManager.currentGM.getGm_name());//�޸ĳ�   ���ã�+��½�û���
	    statusBar.add(label);
	    this.getContentPane().add(statusBar,BorderLayout.SOUTH);
		
	}
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==this.menuItem_Fresh) {
			this.reloadmerchatTable();
		}
		
		else if(e.getSource()==this.menuItem_Addquan){
			FrmAddquan dlg=new FrmAddquan(this,"�����Ż�ȯ",true);
			dlg.setVisible(true);
		}
		else if(e.getSource()==this.menuItem_Changequan){
			int i=FrmYouhuiforGM.this.dataquan.getSelectedRow();
			quanManager.curQuan=allquan.get(i);
			curquan=allquan.get(i);
			FrmChangequan dlg=new FrmChangequan(this,"�޸��Ż�ȯ",true);
			dlg.setVisible(true);
		}
		else if(e.getSource()==this.menuItem_Deletequan){
			int i=FrmYouhuiforGM.this.dataquan.getSelectedRow();
			quanManager.curQuan=allquan.get(i);
			curquan=allquan.get(i);
			if(this.curquan==null) {
				JOptionPane.showMessageDialog(null, "��ѡ���Ż�ȯ", "����",JOptionPane.ERROR_MESSAGE);
				return;
			}
			try {
				wm_assistantUtil.quanmanager.deletequan(allquan.get(i));
			} catch (BaseException e1) {
				JOptionPane.showMessageDialog(null, e1.getMessage(), "����",JOptionPane.ERROR_MESSAGE);
				return;
			}
		}
		
		else if(e.getSource()==this.menuItem_Addmanjian){
			FrmAddmanjian dlg=new FrmAddmanjian(this,"��������",true);
			dlg.setVisible(true);
		}
		else if(e.getSource()==this.menuItem_Changemanjian){
			int i=FrmYouhuiforGM.this.datamanjian.getSelectedRow();
			manjianManager.curmanjian=allmanjian.get(i);
			curmanjian=allmanjian.get(i);
			FrmChangemanjian dlg=new FrmChangemanjian(this,"�޸�����",true);
			dlg.setVisible(true);
		}
		else if(e.getSource()==this.menuItem_Deletemanjian){
			int i=FrmYouhuiforGM.this.datamanjian.getSelectedRow();
			if(i==-1) {
				JOptionPane.showMessageDialog(null, "��ѡ������", "����",JOptionPane.ERROR_MESSAGE);
				return;
			}
			manjianManager.curmanjian=allmanjian.get(i);
			curmanjian=allmanjian.get(i);
			
			try {
				wm_assistantUtil.manjianmanager.deletemanjian(curmanjian);
				curmanjian=null;
			} catch (BaseException e1) {
				JOptionPane.showMessageDialog(null, e1.getMessage(), "����",JOptionPane.ERROR_MESSAGE);
				return;
			}
		}
		
			
	}

}
