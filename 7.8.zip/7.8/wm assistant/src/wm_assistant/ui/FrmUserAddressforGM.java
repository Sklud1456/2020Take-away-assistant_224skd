package wm_assistant.ui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import wm_assistant.begin.wm_assistantUtil;
import wm_assistant.contorl.GMManager;
import wm_assistant.contorl.addressManager;
import wm_assistant.contorl.userManager;
import wm_assistant.model.address;
import wm_assistant.model.merchat;
import wm_assistant.model.product;
import wm_assistant.model.productsort;
import wm_assistant.model.users;
import wm_assistant.util.BaseException;

public class FrmUserAddressforGM extends JDialog implements ActionListener  {
	private JMenuBar menubar=new JMenuBar(); ;
	private JMenu menu_user=new JMenu("�û�");
	private JMenu menu_youhui=new JMenu("��Ϣ");
	private JMenu menu_address=new JMenu("��ַ");
    
    private JMenuItem  menuItem_Addadd=new JMenuItem("�½���ַ");
    private JMenuItem  menuItem_Changeadd=new JMenuItem("�޸ĵ�ַ");
    private JMenuItem  menuItem_Deleteadd=new JMenuItem("ɾ����ַ");
   
    private JMenuItem  menuItem_Flash=new JMenuItem("ˢ��");
    private JMenuItem  menuItem_Yhxq=new JMenuItem("����");
    
    private JPanel statusBar = new JPanel();
    
    private Object addressTitle[]=address.tableTitles;
	private Object addressData[][];
   	DefaultTableModel addressModel=new DefaultTableModel();
   	private JTable dataTableaddress=new JTable(addressModel);
   	
   	private address curaddress=null;
	List<address> alladdress=null;
	
	private void reloadaddressTable(){
		try {
			alladdress=addressManager.loadaddress(userManager.currentuser);
		} catch (BaseException e) {
			JOptionPane.showMessageDialog(null, e.getMessage(), "����",JOptionPane.ERROR_MESSAGE);
			return;
		}
		addressData =  new Object[alladdress.size()][address.tableTitles.length];
		for(int i=0;i<alladdress.size();i++){
			for(int j=0;j<address.tableTitles.length;j++)
				addressData[i][j]=alladdress.get(i).getCell(j);
		}
		addressModel.setDataVector(addressData,addressTitle);
		this.dataTableaddress.validate();
		this.dataTableaddress.repaint();
	}
	public FrmUserAddressforGM(JDialog f, String s, boolean b) {
		this.setSize(1500, 800);
		
		double width = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
		double height = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
		this.setLocation((int) (width - this.getWidth()) / 2,
				(int) (height - this.getHeight()) / 2);
		
		menubar.add(menu_user);this.menu_user.addActionListener(this);
		menubar.add(menu_youhui);this.menu_youhui.addActionListener(this);
		menubar.add(menu_address);this.menu_address.addActionListener(this);
		this.menu_user.add(this.menuItem_Addadd); this.menuItem_Addadd.addActionListener(this);
		this.menu_user.add(this.menuItem_Changeadd); this.menuItem_Changeadd.addActionListener(this);
		this.menu_user.add(this.menuItem_Deleteadd); this.menuItem_Deleteadd.addActionListener(this);
//		this.menu_productsort.add(this.menuItem_Changeps); this.menuItem_Changeps.addActionListener(this);
//		this.menu_productsort.add(this.menuItem_Deleteps); this.menuItem_Deleteps.addActionListener(this);
//		this.menu_product.add(this.menuItem_Addproduct); this.menuItem_Addproduct.addActionListener(this);
//		this.menu_product.add(this.menuItem_Changeproduct); this.menuItem_Changeproduct.addActionListener(this);
//		this.menu_product.add(this.menuItem_Deleteproduct); this.menuItem_Deleteproduct.addActionListener(this);
		this.menu_user.add(this.menuItem_Flash); this.menuItem_Flash.addActionListener(this);
		
//		menubar.add(menu_youhui);this.menu_youhui.addActionListener(this);
//		this.menu_youhui.add(this.menuItem_Yhxq); this.menuItem_Yhxq.addActionListener(this);
		
		this.setJMenuBar(menubar);
		
		this.getContentPane().add(new JScrollPane(this.dataTableaddress), BorderLayout.CENTER);
		this.reloadaddressTable();
	
	    
	    statusBar.setLayout(new FlowLayout(FlowLayout.LEFT));
	    JLabel label=new JLabel("����!"+GMManager.currentGM.getGm_name());//�޸ĳ�   ���ã�+��½�û���
	    statusBar.add(label);
	    this.getContentPane().add(statusBar,BorderLayout.SOUTH);
		
	}
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==this.menuItem_Flash) {
			this.reloadaddressTable();
		}
//		
//		
//		else if(e.getSource()==this.menuItem_Adduser){
//			FrmRegister dlg=new FrmRegister(this,"�����û�",true);
//			dlg.setVisible(true);
//		}
//		else if(e.getSource()==this.menuItem_Changeuser){
//			int i=FrmUserforGM.this.dataTableuser.getSelectedRow();
//			if(i==-1) {
//				JOptionPane.showMessageDialog(null, "��ѡ���û�", "����",JOptionPane.ERROR_MESSAGE);
//				return;
//			}
//			userManager.currentuser=alluser.get(i);
//			FrmChangeuserforGM dlg=new FrmChangeuserforGM(this,"�޸��û���Ϣ",true);
//			dlg.setVisible(true);
//		}
//		else if(e.getSource()==this.menuItem_ChangePwd){
//			int i=FrmUserforGM.this.dataTableuser.getSelectedRow();
//			if(i==-1) {
//				JOptionPane.showMessageDialog(null, "��ѡ���û�", "����",JOptionPane.ERROR_MESSAGE);
//				return;
//			}
//			userManager.currentuser=alluser.get(i);
//			FrmModifyPwdforuser dlg=new FrmModifyPwdforuser(this,"�޸��û���Ϣ",true);
//			dlg.setVisible(true);
//		}
//		else if(e.getSource()==this.menuItem_Deleteuser){
//			int i=FrmUserforGM.this.dataTableuser.getSelectedRow();
//			if(i==-1) {
//				JOptionPane.showMessageDialog(null, "��ѡ���û�", "����",JOptionPane.ERROR_MESSAGE);
//				return;
//			}
//			try {
//				curuser=alluser.get(i);
//				wm_assistantUtil.usermanager.deleteUser(curuser);
//			} catch (BaseException e1) {
//				JOptionPane.showMessageDialog(null, e1.getMessage(), "����",JOptionPane.ERROR_MESSAGE);
//				return;
//			}
//		}
//		
//		
//		else if(e.getSource()==this.menuItem_Addps){
//			FrmAddproductsort dlg=new FrmAddproductsort(this,"��������",true);
//			dlg.setVisible(true);
//		}
//		else if(e.getSource()==this.menuItem_Changeps){
//			FrmChangeproductsort dlg=new FrmChangeproductsort(this,"�޸�����",true);
//			dlg.setVisible(true);
//		}
//		else if(e.getSource()==this.menuItem_Deleteps){
//			if(this.curproductsort==null) {
//				JOptionPane.showMessageDialog(null, "��ѡ������", "����",JOptionPane.ERROR_MESSAGE);
//				return;
//			}
//			try {
//				wm_assistantUtil.productsortmanager.deletesort(curproductsort);
//			} catch (BaseException e1) {
//				JOptionPane.showMessageDialog(null, e1.getMessage(), "����",JOptionPane.ERROR_MESSAGE);
//				return;
//			}
//		}
//		
//		else if(e.getSource()==this.menuItem_Addproduct){
//			FrmAddproduct dlg=new FrmAddproduct(this,"������Ʒ",true);
//			dlg.setVisible(true);
//		}
//		else if(e.getSource()==this.menuItem_Changeproduct){
//			int i=FrmMerchatforGM.this.dataproduct.getSelectedRow();
//			productManager.currentproduct=allproduct.get(i);
//			FrmChangeproduct dlg=new FrmChangeproduct(this,"�޸���Ʒ",true);
//			dlg.setVisible(true);
//		}
//		else if(e.getSource()==this.menuItem_Deleteproduct){
//			int i=FrmMerchatforGM.this.dataproduct.getSelectedRow();
//			productManager.currentproduct=allproduct.get(i);
//			if(this.curproduct==null) {
//				JOptionPane.showMessageDialog(null, "��ѡ����Ʒ", "����",JOptionPane.ERROR_MESSAGE);
//				return;
//			}
//			try {
//				wm_assistantUtil.productmanager.deleteproduct(this.allproduct.get(i));
//			} catch (BaseException e1) {
//				JOptionPane.showMessageDialog(null, e1.getMessage(), "����",JOptionPane.ERROR_MESSAGE);
//				return;
//			}
//		}
//		
//		
//		else if(e.getSource()==this.menuItem_Yhxq){
//			FrmYouhuiforGM dlg=new FrmYouhuiforGM(this,"�Ż���Ϣ",true);
//			dlg.setVisible(true);
//		}
		
		
		
		
			
	}

}
