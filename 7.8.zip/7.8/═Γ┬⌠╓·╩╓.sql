/*
Navicat MySQL Data Transfer

Source Server         : 2020短学期
Source Server Version : 50556
Source Host           : localhost:3306
Source Database       : 外卖助手

Target Server Type    : MYSQL
Target Server Version : 50556
File Encoding         : 65001

Date: 2020-07-03 14:54:33
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for address
-- ----------------------------
DROP TABLE IF EXISTS `address`;
CREATE TABLE `address` (
  `address_no` int(11) NOT NULL AUTO_INCREMENT,
  `user_no` int(11) NOT NULL,
  `address_pri` varchar(10) NOT NULL,
  `address_city` varchar(10) NOT NULL,
  `address_qu` varchar(10) NOT NULL,
  `address_add` varchar(50) NOT NULL,
  `address_man` varchar(10) NOT NULL,
  `address_phone` int(20) NOT NULL,
  PRIMARY KEY (`address_no`),
  KEY `FK_拥有地址` (`user_no`),
  CONSTRAINT `FK_拥有地址` FOREIGN KEY (`user_no`) REFERENCES `user` (`user_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of address
-- ----------------------------

-- ----------------------------
-- Table structure for advise
-- ----------------------------
DROP TABLE IF EXISTS `advise`;
CREATE TABLE `advise` (
  `product_no` int(11) NOT NULL,
  `merchat_no` int(11) NOT NULL,
  `user_no` int(11) NOT NULL,
  `advise_thing` varchar(200) DEFAULT NULL,
  `advise_date` date NOT NULL,
  `advise_star` int(5) DEFAULT NULL,
  `advise_photo` longblob,
  PRIMARY KEY (`product_no`,`merchat_no`,`user_no`),
  KEY `FK_advise2` (`merchat_no`),
  KEY `FK_advise3` (`user_no`),
  CONSTRAINT `FK_advise` FOREIGN KEY (`product_no`) REFERENCES `product` (`product_no`),
  CONSTRAINT `FK_advise2` FOREIGN KEY (`merchat_no`) REFERENCES `merchat` (`merchat_no`),
  CONSTRAINT `FK_advise3` FOREIGN KEY (`user_no`) REFERENCES `user` (`user_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of advise
-- ----------------------------

-- ----------------------------
-- Table structure for gm
-- ----------------------------
DROP TABLE IF EXISTS `gm`;
CREATE TABLE `gm` (
  `gm_no` int(11) NOT NULL,
  `gm_name` varchar(20) NOT NULL,
  `gm_password` varchar(20) NOT NULL,
  PRIMARY KEY (`gm_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of gm
-- ----------------------------

-- ----------------------------
-- Table structure for havequan
-- ----------------------------
DROP TABLE IF EXISTS `havequan`;
CREATE TABLE `havequan` (
  `merchat_no` int(11) NOT NULL,
  `quan_no` int(11) NOT NULL,
  `user_no` int(11) NOT NULL,
  `havequan_youhui` double DEFAULT NULL,
  `havequan_number` int(11) DEFAULT NULL,
  `havequan_enddate` date NOT NULL,
  PRIMARY KEY (`merchat_no`,`quan_no`,`user_no`),
  KEY `FK_havequan2` (`quan_no`),
  KEY `FK_havequan3` (`user_no`),
  CONSTRAINT `FK_havequan` FOREIGN KEY (`merchat_no`) REFERENCES `merchat` (`merchat_no`),
  CONSTRAINT `FK_havequan2` FOREIGN KEY (`quan_no`) REFERENCES `quan` (`quan_no`),
  CONSTRAINT `FK_havequan3` FOREIGN KEY (`user_no`) REFERENCES `user` (`user_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of havequan
-- ----------------------------

-- ----------------------------
-- Table structure for jidan
-- ----------------------------
DROP TABLE IF EXISTS `jidan`;
CREATE TABLE `jidan` (
  `user_no` int(11) NOT NULL,
  `quan_no` int(11) NOT NULL,
  `merchat_no` int(11) NOT NULL,
  `jidian_jidanshu` int(20) DEFAULT NULL,
  `jidan_yiyou` int(20) DEFAULT NULL,
  PRIMARY KEY (`user_no`,`quan_no`,`merchat_no`),
  KEY `FK_jidan2` (`quan_no`),
  KEY `FK_jidan3` (`merchat_no`),
  CONSTRAINT `FK_jidan` FOREIGN KEY (`user_no`) REFERENCES `user` (`user_no`),
  CONSTRAINT `FK_jidan2` FOREIGN KEY (`quan_no`) REFERENCES `quan` (`quan_no`),
  CONSTRAINT `FK_jidan3` FOREIGN KEY (`merchat_no`) REFERENCES `merchat` (`merchat_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of jidan
-- ----------------------------

-- ----------------------------
-- Table structure for manjian
-- ----------------------------
DROP TABLE IF EXISTS `manjian`;
CREATE TABLE `manjian` (
  `manjian_no` int(11) NOT NULL,
  `merchat_no` int(11) NOT NULL,
  `manjian_money` double NOT NULL,
  `havequan_youhui` double NOT NULL,
  `manjian_withquan` tinyint(1) NOT NULL,
  PRIMARY KEY (`manjian_no`),
  KEY `FK_拥有满减` (`merchat_no`),
  CONSTRAINT `FK_拥有满减` FOREIGN KEY (`merchat_no`) REFERENCES `merchat` (`merchat_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of manjian
-- ----------------------------

-- ----------------------------
-- Table structure for merchat
-- ----------------------------
DROP TABLE IF EXISTS `merchat`;
CREATE TABLE `merchat` (
  `merchat_no` int(11) NOT NULL,
  `merchat_name` varchar(20) NOT NULL,
  `merchat_star` int(11) NOT NULL,
  `merchat_conmus` int(11) NOT NULL,
  `merchat_sell` int(11) NOT NULL,
  PRIMARY KEY (`merchat_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of merchat
-- ----------------------------

-- ----------------------------
-- Table structure for orders
-- ----------------------------
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `PO_no` int(11) NOT NULL,
  `product_no` int(11) NOT NULL,
  `orders_num` int(11) DEFAULT NULL,
  `orders_price` double DEFAULT NULL,
  `orders_youhui` double DEFAULT NULL,
  PRIMARY KEY (`PO_no`,`product_no`),
  KEY `FK_orders2` (`product_no`),
  CONSTRAINT `FK_orders2` FOREIGN KEY (`product_no`) REFERENCES `product` (`product_no`),
  CONSTRAINT `FK_orders` FOREIGN KEY (`PO_no`) REFERENCES `productorder` (`PO_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of orders
-- ----------------------------

-- ----------------------------
-- Table structure for product
-- ----------------------------
DROP TABLE IF EXISTS `product`;
CREATE TABLE `product` (
  `product_no` int(11) NOT NULL,
  `productsort_no` int(11) NOT NULL,
  `product_name` varchar(30) NOT NULL,
  `orders_price` double NOT NULL,
  `product_sellprice` bigint(20) NOT NULL,
  PRIMARY KEY (`product_no`),
  KEY `FK_拥有` (`productsort_no`),
  CONSTRAINT `FK_拥有` FOREIGN KEY (`productsort_no`) REFERENCES `productsort` (`productsort_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of product
-- ----------------------------

-- ----------------------------
-- Table structure for productorder
-- ----------------------------
DROP TABLE IF EXISTS `productorder`;
CREATE TABLE `productorder` (
  `PO_no` int(11) NOT NULL,
  `quan_no` int(11) DEFAULT NULL,
  `merchat_no` int(11) NOT NULL,
  `user_no` int(11) NOT NULL,
  `address_no` int(11) NOT NULL,
  `manjian_no` int(11) DEFAULT NULL,
  `rider_no` int(11) NOT NULL,
  `PO_originM` double DEFAULT NULL,
  `PO_finalM` double DEFAULT NULL,
  `PO_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `PO_sendtime` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `PO_sit` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`PO_no`),
  KEY `FK_优惠券商品` (`quan_no`),
  KEY `FK_商家商品` (`merchat_no`),
  KEY `FK_地址商品` (`address_no`),
  KEY `FK_满减商品` (`manjian_no`),
  KEY `FK_用户商品` (`user_no`),
  KEY `FK_骑手商品` (`rider_no`),
  CONSTRAINT `FK_用户商品` FOREIGN KEY (`user_no`) REFERENCES `user` (`user_no`),
  CONSTRAINT `FK_骑手商品` FOREIGN KEY (`rider_no`) REFERENCES `rider` (`rider_no`),
  CONSTRAINT `FK_商家商品` FOREIGN KEY (`merchat_no`) REFERENCES `merchat` (`merchat_no`),
  CONSTRAINT `FK_地址商品` FOREIGN KEY (`address_no`) REFERENCES `address` (`address_no`),
  CONSTRAINT `FK_满减商品` FOREIGN KEY (`manjian_no`) REFERENCES `manjian` (`manjian_no`),
  CONSTRAINT `FK_优惠券商品` FOREIGN KEY (`quan_no`) REFERENCES `quan` (`quan_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of productorder
-- ----------------------------

-- ----------------------------
-- Table structure for productsort
-- ----------------------------
DROP TABLE IF EXISTS `productsort`;
CREATE TABLE `productsort` (
  `productsort_no` int(11) NOT NULL,
  `merchat_no` int(11) NOT NULL,
  `productsort_name` varchar(30) NOT NULL,
  `productdort_number` int(11) NOT NULL,
  PRIMARY KEY (`productsort_no`),
  KEY `FK_品类` (`merchat_no`),
  CONSTRAINT `FK_品类` FOREIGN KEY (`merchat_no`) REFERENCES `merchat` (`merchat_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of productsort
-- ----------------------------

-- ----------------------------
-- Table structure for quan
-- ----------------------------
DROP TABLE IF EXISTS `quan`;
CREATE TABLE `quan` (
  `quan_no` int(11) NOT NULL,
  `merchat_no` int(11) NOT NULL,
  `havequan_youhui` double NOT NULL,
  `jidian_jidan` decimal(20,0) NOT NULL,
  `quan_startdate` datetime NOT NULL,
  `quan_enddate` datetime DEFAULT NULL,
  PRIMARY KEY (`quan_no`),
  KEY `FK_优惠券拥有` (`merchat_no`),
  CONSTRAINT `FK_优惠券拥有` FOREIGN KEY (`merchat_no`) REFERENCES `merchat` (`merchat_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of quan
-- ----------------------------

-- ----------------------------
-- Table structure for rider
-- ----------------------------
DROP TABLE IF EXISTS `rider`;
CREATE TABLE `rider` (
  `rider_no` int(11) NOT NULL,
  `rider_name` varchar(20) NOT NULL,
  `rider_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `rider_ID` varchar(20) NOT NULL,
  PRIMARY KEY (`rider_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of rider
-- ----------------------------

-- ----------------------------
-- Table structure for ridermoney
-- ----------------------------
DROP TABLE IF EXISTS `ridermoney`;
CREATE TABLE `ridermoney` (
  `rider_no` int(11) NOT NULL,
  `PO_no` int(11) NOT NULL,
  `ridermoney_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ridermoney_advise` varchar(200) DEFAULT NULL,
  `ridermoney_money` double DEFAULT NULL,
  PRIMARY KEY (`rider_no`,`PO_no`),
  KEY `FK_ridermoney2` (`PO_no`),
  CONSTRAINT `FK_ridermoney2` FOREIGN KEY (`PO_no`) REFERENCES `productorder` (`PO_no`),
  CONSTRAINT `FK_ridermoney` FOREIGN KEY (`rider_no`) REFERENCES `rider` (`rider_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ridermoney
-- ----------------------------

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `user_no` int(11) NOT NULL,
  `user_name` varchar(20) NOT NULL,
  `user_sex` varchar(10) NOT NULL,
  `user_password` varchar(30) NOT NULL,
  `user_phone` varchar(20) NOT NULL,
  `user_mail` varchar(30) DEFAULT NULL,
  `user_city` varchar(20) NOT NULL,
  `user_createtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `user_vip` tinyint(1) DEFAULT NULL,
  `user_vipenddate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`user_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
